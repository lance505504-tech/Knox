// netlify/functions/stripe-webhook.js
// Receives Stripe webhook events after a payment succeeds or fails.
// Writes the payment result to Netlify Blob Storage so the CMS picks it up.
//
// Required environment variables (set in Netlify dashboard):
//   STRIPE_SECRET_KEY        — Stripe secret key
//   STRIPE_WEBHOOK_SECRET    — from Stripe Dashboard → Webhooks → your endpoint → signing secret
//
// Webhook endpoint to register in Stripe Dashboard:
//   https://YOUR-NETLIFY-SITE.netlify.app/.netlify/functions/stripe-webhook
// Events to subscribe to:
//   checkout.session.completed
//   checkout.session.expired
//   payment_intent.payment_failed

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// We store payment results in a simple key-value store using Netlify Blob Storage.
// The CMS polls /.netlify/functions/get-payment-status?id=PAYMENT_ID to check.
// We keep it simple: store as JSON in a pseudo-storage via environment + in-memory
// For production: replace with Netlify Blobs, FaunaDB, or any key-value store.

// Payment results are written to Netlify Blobs (available on all Netlify plans)
async function storePaymentResult(paymentId, result) {
  // Store in Netlify Blob Storage
  // This requires the @netlify/blobs package — we use fetch directly to keep deps minimal
  const storeUrl = `https://api.netlify.com/api/v1/blobs/${process.env.NETLIFY_SITE_ID}/cape31-payments/${encodeURIComponent(paymentId)}`;
  try {
    await fetch(storeUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${process.env.NETLIFY_ACCESS_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(result)
    });
  } catch (e) {
    // Fallback: log to console — CMS can poll Stripe directly as fallback
    console.log('PAYMENT_RESULT', JSON.stringify({ paymentId, ...result }));
  }
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  const session = stripeEvent.data.object;

  switch (stripeEvent.type) {

    case 'checkout.session.completed': {
      // Payment succeeded
      const paymentId   = session.metadata?.cape31_paymentId;
      const paymentType = session.metadata?.cape31_type;
      if (!paymentId) break;

      const result = {
        status:        'paid',
        paymentId,
        paymentType,
        stripeSession: session.id,
        amount:        session.amount_total,       // pence
        currency:      session.currency,
        customerEmail: session.customer_email,
        paidAt:        new Date().toISOString(),
        metadata:      session.metadata
      };

      await storePaymentResult(paymentId, result);
      console.log(`Payment confirmed: ${paymentId} (${paymentType}) — £${(session.amount_total / 100).toFixed(2)}`);
      break;
    }

    case 'checkout.session.expired': {
      const paymentId = session.metadata?.cape31_paymentId;
      if (paymentId) {
        await storePaymentResult(paymentId, {
          status: 'expired',
          paymentId,
          stripeSession: session.id,
          expiredAt: new Date().toISOString()
        });
      }
      break;
    }

    case 'payment_intent.payment_failed': {
      const pi = stripeEvent.data.object;
      console.log(`Payment failed: ${pi.id} — ${pi.last_payment_error?.message}`);
      break;
    }

    default:
      // Ignore other events
      break;
  }

  // Always return 200 quickly — Stripe will retry if we return an error
  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
