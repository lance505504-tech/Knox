// netlify/functions/get-payment-status.js
// The CMS calls this to check whether a payment has been confirmed by Stripe.
// Query: /.netlify/functions/get-payment-status?id=PAYMENT_ID
//
// Required environment variables:
//   NETLIFY_SITE_ID      — found in Netlify dashboard → Site settings → General
//   NETLIFY_ACCESS_TOKEN — a personal access token from Netlify → User settings → OAuth

exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  // Origin check
  const origin = event.headers['origin'] || event.headers['referer'] || '';
  const siteUrl = process.env.URL || '';
  const allowedOrigins = [siteUrl, 'http://localhost:8888', 'http://localhost:3000'].filter(Boolean);
  const originAllowed = !origin || allowedOrigins.some(o => origin.startsWith(o));
  if (!originAllowed) {
    return { statusCode: 403, body: JSON.stringify({ error: 'Forbidden' }) };
  }

  const paymentId = event.queryStringParameters?.id;
  if (!paymentId) {
    return { statusCode: 400, body: JSON.stringify({ error: 'id parameter required' }) };
  }

  // Sanitise paymentId — only allow safe characters
  const safeId = String(paymentId).slice(0, 64).replace(/[^a-zA-Z0-9_\-]/g, '');
  if (!safeId) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid payment ID' }) };
  }

  const storeUrl = `https://api.netlify.com/api/v1/blobs/${process.env.NETLIFY_SITE_ID}/cape31-payments/${encodeURIComponent(safeId)}`;

  try {
    const res = await fetch(storeUrl, {
      headers: { 'Authorization': `Bearer ${process.env.NETLIFY_ACCESS_TOKEN}` }
    });

    if (res.status === 404) {
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'pending' })
      };
    }

    const data = await res.json();
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    };

  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
