// netlify/functions/create-checkout.js
// Creates a Stripe Checkout session for class fees, regatta entries, or ad-hoc items.
// Called by the CMS when an admin or owner clicks "Pay now".
//
// Required environment variables (set in Netlify dashboard):
//   STRIPE_SECRET_KEY        — from Stripe Dashboard → Developers → API keys
//   STRIPE_PUBLISHABLE_KEY   — from same place (starts with pk_)
//   URL                      — set automatically by Netlify (your site URL)

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  // Only accept POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  // CORS / origin check — only accept requests from our own domain
  const origin = event.headers['origin'] || event.headers['referer'] || '';
  const siteUrl = process.env.URL || '';
  const allowedOrigins = [
    siteUrl,
    'http://localhost:8888',   // netlify dev
    'http://localhost:3000',
  ].filter(Boolean);

  const originAllowed = !origin || allowedOrigins.some(o => origin.startsWith(o));
  if (!originAllowed) {
    console.warn('Blocked request from origin:', origin);
    return { statusCode: 403, body: JSON.stringify({ error: 'Forbidden' }) };
  }

  // Validate Stripe is configured
  if (!process.env.STRIPE_SECRET_KEY) {
    return {
      statusCode: 503,
      body: JSON.stringify({ error: 'Payment system not configured — contact administrator' })
    };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  // Expected body fields:
  //   type        — 'class_fee' | 'regatta_entry' | 'adhoc'
  //   paymentId   — our internal ID (e.g. fee record ID or entry ID)
  //   amount      — amount in pence/cents (integer, e.g. 15000 = £150.00)
  //   currency    — 'gbp' (default)
  //   description — human-readable label shown on Stripe checkout
  //   customerEmail — pre-fill the payer's email (optional)
  //   metadata    — object of any extra fields to store (boatName, hull, etc.)

  const {
    type,
    paymentId,
    amount,
    currency = 'gbp',
    description,
    customerEmail,
    metadata = {}
  } = body;

  if (!paymentId || !amount || !description) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'paymentId, amount and description are required' })
    };
  }

  // Sanitise amount — must be a positive integer, max £10,000 (1,000,000 pence)
  const amountInt = Math.floor(Number(amount));
  if (!Number.isFinite(amountInt) || amountInt <= 0 || amountInt > 1000000) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid amount — must be between £0.01 and £10,000' })
    };
  }

  // Sanitise description
  const safeDescription = String(description).slice(0, 200).replace(/[<>"']/g, '');
  const safePaymentId   = String(paymentId).slice(0, 64).replace(/[^a-zA-Z0-9_\-]/g, '');

  const siteUrl = process.env.URL || 'http://localhost:8888';

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      customer_email: customerEmail || undefined,
      line_items: [
        {
          price_data: {
            currency,
            unit_amount: amountInt,    // in pence (sanitised)
            product_data: {
              name: safeDescription,
              description: `Cape 31 Class — ${type === 'class_fee' ? 'Class Membership Fee' : type === 'regatta_entry' ? 'Regatta Entry Fee' : 'Payment'}`,
            },
          },
          quantity: 1,
        },
      ],
      metadata: {
        // These are passed back verbatim in the webhook so we can identify the payment
        cape31_type:      type,
        cape31_paymentId: safePaymentId,
        ...metadata
      },
      // After payment, Stripe redirects back to our CMS with the session ID
      success_url: `${siteUrl}/cape31-class-management.html?payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${siteUrl}/cape31-class-management.html?payment=cancelled`,
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: session.url, sessionId: session.id })
    };

  } catch (err) {
    console.error('Stripe error:', err.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
