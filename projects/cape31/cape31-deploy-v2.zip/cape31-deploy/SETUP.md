# Cape 31 Class System — Deployment & Stripe Setup Guide

## What's in this folder

```
cape31-deploy/
├── public/
│   ├── cape31-auth.html              ← Single sign-on page (start here)
│   ├── cape31-sail-register.html     ← IHC Sail Button Register
│   └── cape31-class-management.html  ← Class Management System + Payments
├── netlify/
│   └── functions/
│       ├── create-checkout.js        ← Creates Stripe Checkout sessions
│       ├── stripe-webhook.js         ← Receives payment confirmations from Stripe
│       └── get-payment-status.js     ← CMS polls this to check payment status
├── package.json                      ← Node dependencies (Stripe SDK)
├── netlify.toml                      ← Netlify build config
└── SETUP.md                          ← This file
```

---

## Step 1 — Deploy to Netlify (free)

1. Go to [app.netlify.com](https://app.netlify.com) and sign up / sign in
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag the entire **`cape31-deploy`** folder onto the drop zone
4. Netlify deploys in ~30 seconds and gives you a URL like `https://cape31-class.netlify.app`
5. You can rename this under **Site settings → General → Site name**

> **Your site is now live.** The auth, sail register and CMS all work — without Stripe yet.
> Payments show as "Stripe not configured" until Step 3.

---

## Step 2 — Set up a Stripe account

1. Go to [stripe.com](https://stripe.com) and create a free account
2. Complete business verification (required to accept real payments)
3. In the Stripe Dashboard, go to **Developers → API keys**
4. You'll see two keys:
   - **Publishable key** — starts with `pk_live_...` (safe to share)
   - **Secret key** — starts with `sk_live_...` (keep private, never put in HTML)

> Use **test mode** first (keys start with `pk_test_` / `sk_test_`). Switch to live when ready.

---

## Step 3 — Add Stripe keys to Netlify

1. In your Netlify dashboard, go to **Site settings → Environment variables**
2. Add these variables (click "Add a variable" for each):

| Variable name | Value | Notes |
|---|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` | From Stripe → Developers → API keys |
| `STRIPE_PUBLISHABLE_KEY` | `pk_live_...` | From same page |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` | From Step 4 below |
| `NETLIFY_SITE_ID` | your site ID | From Netlify → Site settings → General |
| `NETLIFY_ACCESS_TOKEN` | your token | From Netlify → User settings → OAuth applications → Personal access tokens |

3. After adding all variables, go to **Deploys → Trigger deploy → Deploy site** to pick them up

---

## Step 4 — Register the Stripe webhook

This is what makes payments update automatically in the CMS.

1. In Stripe Dashboard, go to **Developers → Webhooks**
2. Click **"Add endpoint"**
3. Set the **Endpoint URL** to:
   ```
   https://YOUR-SITE.netlify.app/.netlify/functions/stripe-webhook
   ```
   (replace `YOUR-SITE` with your actual Netlify subdomain)
4. Under **"Select events to listen to"**, add:
   - `checkout.session.completed`
   - `checkout.session.expired`
   - `payment_intent.payment_failed`
5. Click **"Add endpoint"**
6. On the next screen, click **"Reveal signing secret"** — copy the `whsec_...` value
7. Go back to Netlify → Environment variables and paste it as `STRIPE_WEBHOOK_SECRET`
8. Redeploy the site

---

## Step 5 — Configure the class fee amount

1. Open `cape31-class-management.html` on your live site and sign in as admin
2. Go to **Admin tab → System → Payment settings**
3. Set the **Class fee amount** (e.g. 300.00 for £300)
4. This is used as the default when generating class fee payment links

---

## How payments work (day-to-day)

### Class membership fee
1. Go to **Class Fees tab**
2. Find the boat, click **💳 Pay online**
3. A Stripe checkout page opens — the owner pays by card
4. Stripe confirms payment → webhook fires → CMS automatically marks the fee as **Paid**

### Regatta entry fee  
1. Go to **Entries & Crew tab**, find the entry
2. Click **💳 Pay online**
3. Same flow — pays on Stripe, entry fee auto-marked paid

### Ad-hoc items
1. Go to **💳 Payments tab**
2. Click **+ Ad-hoc payment**
3. Enter description, amount, optional payer email
4. Stripe checkout opens — or copy the link to send separately

### Bank transfer / offline payment
- Any payment record has a **Mark paid** button for cash or bank transfer
- This manually marks it paid without going through Stripe

---

## Stripe fees
- UK cards: ~1.5% + 20p per transaction
- European cards: ~1.5% + 20p
- No monthly fees — only pay when you take a payment
- Full pricing at [stripe.com/gb/pricing](https://stripe.com/gb/pricing)

---

## Testing before going live

1. In Stripe Dashboard, make sure you're in **Test mode** (toggle at bottom left)
2. Use test card number `4242 4242 4242 4242`, any future expiry, any CVC
3. When satisfied, switch Stripe to **Live mode** and update the keys in Netlify

---

## Using on laptop (no server)

When opening the HTML files directly from your laptop (`file://` URLs):
- The auth redirect doesn't fire — each file shows its own login screen
- Stripe payments won't work (needs the Netlify functions)
- Everything else (sail buttons, entries, fees, crew) works normally
- To test payments locally, use [Netlify CLI](https://docs.netlify.com/cli/get-started/):
  ```bash
  npm install -g netlify-cli
  cd cape31-deploy
  netlify dev
  ```
  Then open `http://localhost:8888`

---

## Admin credentials

- **Lance Adams:** `lance551025@yahoo.co.uk` / `Office2026`
- **Dave Swete:** `dave@swetesailing.com` / `Office2026`

Change passwords after first login via the account menu (top right).

---

## Security notes

Passwords are **never stored in plaintext**. The system uses SHA-256 hashing (browser's built-in SubtleCrypto API — no external library) with a fixed salt. Pre-hashed values are embedded for the seed admin accounts.

**First login migration:** If any user account was created before this version (with a plaintext password), it is automatically migrated to a hash on their next successful login. No action needed.

**What this protects against:**
- Anyone who views the page source cannot see passwords
- Browser extensions that read localStorage cannot see passwords
- If a device is lost, localStorage contents cannot be used to recover passwords

**What this does NOT replace:**
- This is a client-side static site — there is no server-side auth. For higher security, use Netlify Identity or Auth0.
- Passwords should still be strong and changed after first login.

**Content Security Policy** is set in `netlify.toml` and allows only known safe origins (Stripe, the class CDN, Wix assets). If you add new external resources, add them to the CSP header.

---

## Need to make changes?

Don't edit the files directly — ask for changes via chat and they'll be applied carefully 
without touching the data. When a new version is ready, just drag the updated folder to 
Netlify again to redeploy.
