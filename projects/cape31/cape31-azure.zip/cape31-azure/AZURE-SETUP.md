# Cape 31 Class System — Azure Deployment Guide

## What's in this folder

```
cape31-azure/
├── public/
│   ├── cape31-auth.html              ← Single sign-on (start here)
│   ├── cape31-sail-register.html     ← IHC Sail Button Register
│   ├── cape31-class-management.html  ← Class Management + Payments
│   └── staticwebapp.config.json      ← Azure routes + security headers
└── api/
    ├── host.json                     ← Azure Functions runtime config
    ├── package.json                  ← Node dependencies (Stripe)
    ├── create-checkout/
    │   ├── index.js                  ← Creates Stripe Checkout sessions
    │   └── function.json
    ├── get-payment-status/
    │   ├── index.js                  ← Queries Stripe for payment status
    │   └── function.json
    └── stripe-webhook/
        ├── index.js                  ← Receives Stripe payment confirmations
        └── function.json
```

---

## STEP 1 — Create a Static Web App in Azure Portal

1. Go to **portal.azure.com** and sign in
2. Click **"Create a resource"** → search **"Static Web App"** → click **Create**
3. Fill in:
   - **Subscription:** your subscription
   - **Resource group:** create new → name it `cape31-class` (or add to existing)
   - **Name:** `swa-cape31-class` (or similar)
   - **Plan type:** Free (sufficient for this)
   - **Region:** UK South or North Europe
   - **Deployment source:** select **"Other"** (we deploy manually via CLI)
4. Click **Review + Create** → **Create**
5. Once deployed, click **"Go to resource"**
6. Copy the **URL** shown (something like `https://happy-wave-123.azurestaticapps.net`) — you'll need this
7. Go to **"Manage deployment token"** in the left panel and copy the token

---

## STEP 2 — Install the SWA CLI (one-time, if not already installed)

```powershell
npm install -g @azure/static-web-apps-cli
```

---

## STEP 3 — Deploy

Unzip `cape31-azure.zip` to a folder, then run:

```powershell
cd path\to\cape31-azure

npx @azure/static-web-apps-cli deploy . `
  --app-location public `
  --api-location api `
  --deployment-token YOUR_TOKEN_HERE `
  --env production
```

Replace `YOUR_TOKEN_HERE` with the token from Step 1.

**That's it — the site is live.** Open the URL from Step 1 to confirm.

> Payments will show "Stripe not configured" until Step 4. Everything else works.

---

## STEP 4 — Add environment variables (for Stripe payments)

In Azure Portal → your Static Web App → **Configuration** (left sidebar):

Click **"+ Add"** for each of these:

| Name | Value | Notes |
|---|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` | From Stripe → Developers → API keys |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` | From Step 5 below |
| `SITE_URL` | `https://YOUR-SITE.azurestaticapps.net` | Your Azure URL (or custom domain) |

Click **Save** at the top. The functions restart automatically.

> Use `sk_test_` keys while testing — switch to `sk_live_` when ready for real payments.

---

## STEP 5 — Register the Stripe webhook

This makes payments auto-confirm in the CMS.

1. Go to **dashboard.stripe.com → Developers → Webhooks**
2. Click **"Add endpoint"**
3. Set the **Endpoint URL** to:
   ```
   https://YOUR-SITE.azurestaticapps.net/api/stripe-webhook
   ```
4. Under **"Select events"** add:
   - `checkout.session.completed`
   - `checkout.session.expired`
   - `payment_intent.payment_failed`
5. Click **"Add endpoint"** → click **"Reveal signing secret"**
6. Copy the `whsec_...` value → paste as `STRIPE_WEBHOOK_SECRET` in Azure Configuration (Step 4)

---

## STEP 6 — Set the class fee amount

1. Sign in to the Class Management System
2. Go to **Admin tab → System → Payment settings**
3. Set the class fee amount (e.g. `300.00` for £300)

---

## STEP 7 — Custom domain (migrate to your own URL)

To use a domain like `class.cape31class.com` instead of the Azure URL:

### In Azure Portal:
1. Go to your Static Web App → **Custom domains** (left sidebar)
2. Click **"+ Add"**
3. Enter your domain, e.g. `class.cape31class.com`
4. Azure will show you a **CNAME record** to create, like:
   ```
   CNAME  class  →  happy-wave-123.azurestaticapps.net
   ```

### In your DNS provider (wherever cape31class.com is managed):
5. Add that CNAME record
6. Back in Azure, click **"Validate"** — Azure checks the DNS
7. Once validated, click **"Add"** — Azure provisions a free SSL certificate automatically

**Important:** Once your custom domain is live, update the `SITE_URL` environment variable in Azure Configuration to match (e.g. `https://class.cape31class.com`) — this is used in the Stripe redirect URL.

Also update the Stripe webhook endpoint URL in the Stripe Dashboard to your new domain.

---

## Redeployment (when new files are available)

Just run the deploy command again from Step 3 — it overwrites only changed files.

---

## Admin credentials

- **Lance Adams:** `lance551025@yahoo.co.uk` / `Office2026`
- **Dave Swete:** `dave@swetesailing.com` / `Office2026`

Change passwords after first login via the account menu (top right).

---

## Testing Stripe (before going live)

1. In Stripe Dashboard, ensure you're in **Test mode** (toggle bottom-left)
2. Use test card: `4242 4242 4242 4242`, any future expiry, any CVC
3. When ready, switch to **Live mode** and update `STRIPE_SECRET_KEY` in Azure Configuration

---

## How payments work differently from Netlify

The Azure version queries Stripe directly to check payment status — no separate
blob storage is needed. When you click "Check" on a pending payment, the function
calls Stripe's API with the session ID and returns the live status.

This means:
- Simpler infrastructure (no storage account needed)
- Payment status is always real-time accurate
- The Stripe webhook is still active for logging and future extensions
