// api/create-checkout/index.js
// Creates a Stripe Checkout session for class fees, regatta entries, or ad-hoc items.
// Azure Static Web Apps API function — called by the CMS when an admin clicks "Pay now".
//
// Required environment variables (set in Azure Portal → Static Web App → Configuration):
//   STRIPE_SECRET_KEY    — from Stripe Dashboard → Developers → API keys (sk_live_...)
//   SITE_URL             — your Azure domain, e.g. https://cape31.azurestaticapps.net

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

module.exports = async function (context, req) {

  // Only accept POST
  if (req.method !== 'POST') {
    context.res = { status: 405, body: 'Method Not Allowed' };
    return;
  }

  // CORS / origin check — only accept requests from our own domain
  const origin  = req.headers['origin'] || req.headers['referer'] || '';
  const siteUrl = process.env.SITE_URL || '';
  const allowed = [siteUrl, 'http://localhost:4280', 'http://localhost:3000'].filter(Boolean);
  const originOk = !origin || allowed.some(o => origin.startsWith(o));
  if (!originOk) {
    context.log.warn('Blocked request from origin:', origin);
    context.res = { status: 403, body: JSON.stringify({ error: 'Forbidden' }) };
    return;
  }

  // Validate Stripe is configured
  if (!process.env.STRIPE_SECRET_KEY) {
    context.res = {
      status: 503,
      body: JSON.stringify({ error: 'Payment system not configured — add STRIPE_SECRET_KEY in Azure Portal → Configuration' })
    };
    return;
  }

  // Parse body
  let body;
  try {
    body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch (e) {
    context.res = { status: 400, body: JSON.stringify({ error: 'Invalid JSON' }) };
    return;
  }

  const {
    type,
    paymentId,
    amount,
    currency    = 'gbp',
    description,
    customerEmail,
    metadata    = {}
  } = body || {};

  if (!paymentId || !amount || !description) {
    context.res = {
      status: 400,
      body: JSON.stringify({ error: 'paymentId, amount and description are required' })
    };
    return;
  }

  // Sanitise — amount must be a positive integer pence value, max £10,000
  const amountInt = Math.floor(Number(amount));
  if (!Number.isFinite(amountInt) || amountInt <= 0 || amountInt > 1000000) {
    context.res = {
      status: 400,
      body: JSON.stringify({ error: 'Invalid amount — must be between £0.01 and £10,000' })
    };
    return;
  }

  const safeDesc      = String(description).slice(0, 200).replace(/[<>"']/g, '');
  const safePaymentId = String(paymentId).slice(0, 64).replace(/[^a-zA-Z0-9_-]/g, '');
  const redirectBase  = siteUrl || 'http://localhost:4280';

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      customer_email: customerEmail || undefined,
      line_items: [{
        price_data: {
          currency,
          unit_amount: amountInt,
          product_data: {
            name: safeDesc,
            description: `Cape 31 Class — ${
              type === 'class_fee'      ? 'Class Membership Fee' :
              type === 'regatta_entry'  ? 'Regatta Entry Fee'    : 'Payment'
            }`,
          },
        },
        quantity: 1,
      }],
      metadata: {
        cape31_type:      type,
        cape31_paymentId: safePaymentId,
        ...metadata
      },
      success_url: `${redirectBase}/cape31-class-management.html?payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${redirectBase}/cape31-class-management.html?payment=cancelled`,
    });

    context.res = {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: session.url, sessionId: session.id })
    };

  } catch (err) {
    context.log.error('Stripe error:', err.message);
    context.res = {
      status: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
