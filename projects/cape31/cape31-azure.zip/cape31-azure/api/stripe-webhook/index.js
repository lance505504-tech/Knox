// api/stripe-webhook/index.js
// Receives Stripe webhook events after a payment succeeds or fails.
// Since get-payment-status now queries Stripe directly, this webhook is used
// for logging and any server-side actions (email notifications, etc.)
//
// Required environment variables:
//   STRIPE_SECRET_KEY       — Stripe secret key
//   STRIPE_WEBHOOK_SECRET   — from Stripe Dashboard → Webhooks → signing secret (whsec_...)
//
// Webhook endpoint to register in Stripe Dashboard:
//   https://YOUR-AZURE-SITE.azurestaticapps.net/api/stripe-webhook
//
// Events to subscribe to:
//   checkout.session.completed
//   checkout.session.expired
//   payment_intent.payment_failed

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

module.exports = async function (context, req) {

  if (req.method !== 'POST') {
    context.res = { status: 405, body: 'Method Not Allowed' };
    return;
  }

  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    context.log.warn('STRIPE_WEBHOOK_SECRET not set — skipping signature verification');
    context.res = { status: 200, body: JSON.stringify({ received: true }) };
    return;
  }

  const sig = req.headers['stripe-signature'];

  // Azure passes body as parsed object by default — we need the raw string for Stripe signature
  // Azure Functions v3/v4: rawBody is available when content-type is application/json
  const rawBody = req.rawBody || (typeof req.body === 'string' ? req.body : JSON.stringify(req.body));

  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    context.log.error('Webhook signature verification failed:', err.message);
    context.res = { status: 400, body: `Webhook Error: ${err.message}` };
    return;
  }

  const obj = stripeEvent.data.object;

  switch (stripeEvent.type) {

    case 'checkout.session.completed': {
      const paymentId   = obj.metadata?.cape31_paymentId;
      const paymentType = obj.metadata?.cape31_type;
      const amount      = obj.amount_total;
      context.log(`✓ Payment confirmed: ${paymentId} (${paymentType}) — £${(amount / 100).toFixed(2)}`);
      // Payment status is read directly from Stripe by get-payment-status.
      // No storage write needed — the CMS polls /api/get-payment-status?session_id=cs_xxx
      break;
    }

    case 'checkout.session.expired': {
      const paymentId = obj.metadata?.cape31_paymentId;
      context.log(`Session expired: ${paymentId}`);
      break;
    }

    case 'payment_intent.payment_failed': {
      context.log(`Payment failed: ${obj.id} — ${obj.last_payment_error?.message}`);
      break;
    }

    default:
      break;
  }

  // Always return 200 quickly — Stripe retries on errors
  context.res = { status: 200, body: JSON.stringify({ received: true }) };
};
