// api/get-payment-status/index.js
// Checks whether a Stripe Checkout session has been paid.
// Queries Stripe directly — no separate storage service needed.
//
// The CMS calls this as:
//   GET /api/get-payment-status?session_id=cs_xxx
//
// Required environment variables:
//   STRIPE_SECRET_KEY — your Stripe secret key

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

module.exports = async function (context, req) {

  if (req.method !== 'GET') {
    context.res = { status: 405, body: 'Method Not Allowed' };
    return;
  }

  // Origin check
  const origin  = req.headers['origin'] || req.headers['referer'] || '';
  const siteUrl = process.env.SITE_URL || '';
  const allowed = [siteUrl, 'http://localhost:4280', 'http://localhost:3000'].filter(Boolean);
  const originOk = !origin || allowed.some(o => origin.startsWith(o));
  if (!originOk) {
    context.res = { status: 403, body: JSON.stringify({ error: 'Forbidden' }) };
    return;
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    context.res = { status: 503, body: JSON.stringify({ error: 'Stripe not configured' }) };
    return;
  }

  // Accept either session_id (Stripe session) or payment_id (internal, legacy)
  const sessionId = req.query?.session_id;
  if (!sessionId) {
    context.res = { status: 400, body: JSON.stringify({ error: 'session_id parameter required' }) };
    return;
  }

  // Sanitise — Stripe session IDs are cs_xxx format
  const safeSessionId = String(sessionId).slice(0, 128).replace(/[^a-zA-Z0-9_-]/g, '');
  if (!safeSessionId.startsWith('cs_')) {
    context.res = { status: 400, body: JSON.stringify({ error: 'Invalid session_id format' }) };
    return;
  }

  try {
    const session = await stripe.checkout.sessions.retrieve(safeSessionId);

    if (session.payment_status === 'paid') {
      context.res = {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status:        'paid',
          paymentId:     session.metadata?.cape31_paymentId,
          paymentType:   session.metadata?.cape31_type,
          stripeSession: session.id,
          amount:        session.amount_total,
          currency:      session.currency,
          customerEmail: session.customer_email,
          paidAt:        new Date(session.created * 1000).toISOString(),
        })
      };
    } else if (session.status === 'expired') {
      context.res = {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'expired', stripeSession: session.id })
      };
    } else {
      context.res = {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'pending' })
      };
    }

  } catch (err) {
    context.log.error('Stripe error:', err.message);
    context.res = {
      status: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
